# Directory overview


## programs

Contains Python (as well as some Fortran and Julia) scripts used in the demos and exercises


## hpc2n

Contains batch scripts that will run on HPC2N's Kebnekaise cluster


## uppmax 

Contains batch scripts that will run on UPPMAX's Rackham cluster



