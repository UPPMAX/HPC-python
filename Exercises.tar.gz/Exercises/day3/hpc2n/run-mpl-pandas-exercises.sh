#!/bin/bash
# Remember to change this to your own project ID!
#SBATCH -A hpc2n2026-002
# We are asking for 5 minutes
#SBATCH --time=00:05:00
# Asking for one core (may need more for a couple Pandas exercises)
#SBATCH -n 1 

# Change to the directory where the data files and program are located
# Change the below to your own path to where you placed the example programs
cd /proj/nobackup/spring-courses/<mydir-name>/Exercises/day3/programs/

# Remove any loaded modules and load the ones we need
module purge  > /dev/null 2>&1
module load GCC/12.3.0 Python/3.11.3 SciPy-bundle/2023.07 matplotlib/3.7.2  
# includes Pandas

# Run your Python script
python matplotlib-intro.py
# change script name as needed
