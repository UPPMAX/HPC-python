Directory overview


programs

Contains Python (as well as some Fortran and Julia) scripts used in the demos and exercises


hpc2n, uppmax, cosmos, nsc, pdc, c3se

Contains batch scripts that will run on that specific center's cluster



